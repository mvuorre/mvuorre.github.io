"This .zip file contains all behavioural data as separate files. For more information regarding the data structure, see the Behavioural_data_description.txt file included"
